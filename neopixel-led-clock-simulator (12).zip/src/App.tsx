import React, { useState, useEffect } from 'react';
import { Settings, Clock, Palette, Play, Pause, RotateCcw } from 'lucide-react';
import Digit from './components/Digit';
import ArduinoCode from './components/ArduinoCode';
import { PRESET_COLORS } from './constants';

enum Mode { NORMAL, SET_TIME, SET_DATE, SHOW_TEMP }

export default function App() {
  // Simulator State
  const [time, setTime] = useState(new Date());
  const [currentMode, setCurrentMode] = useState<Mode>(Mode.NORMAL);
  const [settingIndex, setSettingIndex] = useState(0);
  const [colorIndex, setColorIndex] = useState(0);
  const [use12h, setUse12h] = useState(false);
  const [baseHue, setBaseHue] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Temporary values for setting
  const [tempTime, setTempTime] = useState({
    hour: new Date().getHours(),
    minute: new Date().getMinutes(),
    day: new Date().getDate(),
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear()
  });

  // Animation loop for rainbow
  useEffect(() => {
    const interval = setInterval(() => {
      setBaseHue(prev => (prev + 2) % 360);
    }, 30);
    return () => clearInterval(interval);
  }, []);

  // Real-time clock update
  useEffect(() => {
    if (isPaused || currentMode !== Mode.NORMAL) return;
    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, [isPaused, currentMode]);

  const handleMode = () => {
    if (currentMode === Mode.NORMAL) {
      setCurrentMode(Mode.SET_TIME);
      setSettingIndex(0);
    } else if (currentMode === Mode.SET_TIME) {
      if (settingIndex === 0) setSettingIndex(1);
      else {
        setCurrentMode(Mode.SET_DATE);
        setSettingIndex(0);
      }
    } else if (currentMode === Mode.SET_DATE) {
      if (settingIndex < 2) setSettingIndex(prev => prev + 1);
      else {
        setCurrentMode(Mode.NORMAL);
        setSettingIndex(0);
      }
    } else if (currentMode === Mode.SHOW_TEMP) {
      setCurrentMode(Mode.NORMAL);
    }
  };

  const handleAdjust = (delta: number) => {
    if (currentMode === Mode.SET_TIME) {
      if (settingIndex === 0) setTempTime(p => ({ ...p, hour: (p.hour + delta + 24) % 24 }));
      else setTempTime(p => ({ ...p, minute: (p.minute + delta + 60) % 60 }));
    } else if (currentMode === Mode.SET_DATE) {
      if (settingIndex === 0) setTempTime(p => ({ ...p, day: Math.max(1, Math.min(31, p.day + delta)) }));
      else if (settingIndex === 1) setTempTime(p => ({ ...p, month: (p.month + delta - 1 + 12) % 12 + 1 }));
      else setTempTime(p => ({ ...p, year: p.year + delta }));
    }
  };

  const isRainbow = colorIndex === PRESET_COLORS.length;
  const currentColor = isRainbow ? 'rainbow' : PRESET_COLORS[colorIndex];

  const getDisplayHour = () => {
    const h = currentMode === Mode.NORMAL ? time.getHours() : tempTime.hour;
    if (!use12h) return h;
    const h12 = h % 12;
    return h12 === 0 ? 12 : h12;
  };

  const getDisplayMinute = () => currentMode === Mode.NORMAL ? time.getMinutes() : tempTime.minute;
  const getDisplaySecond = () => time.getSeconds();

  const enhancedArduinoCode = `#include <Wire.h>
#include "RTClib.h"
#include <Adafruit_NeoPixel.h>
#include <EEPROM.h>

#define LED_PIN 6
#define NUMPIXELS 284
#define BRIGHTNESS 50

// Buttons (active LOW)
#define BTN_MODE 2
#define BTN_UP 3
#define BTN_DOWN 4
#define BTN_COLOR 5
#define BTN_1224 7

Adafruit_NeoPixel strip(NUMPIXELS, LED_PIN, NEO_GRB + NEO_KHZ800);
RTC_DS3231 rtc;

// Segment LED counts
const int hourMinuteSegLEDs = 4;
const int secondSegLEDs = 3;
const int bottomSegLEDs = 2;
int digitStart[14];

// Digit segment mapping: G,B,A,F,E,D,C
byte digitCode[14][7] = {
  {0,1,1,1,1,1,1}, // 0
  {0,1,0,0,0,0,1}, // 1
  {1,1,1,0,1,1,0}, // 2
  {1,1,1,0,0,1,1}, // 3
  {1,1,0,1,0,0,1}, // 4
  {1,0,1,1,0,1,1}, // 5
  {1,0,1,1,1,1,1}, // 6
  {0,1,1,0,0,0,1}, // 7
  {1,1,1,1,1,1,1}, // 8
  {1,1,1,1,0,1,1}, // 9
  {0,0,0,0,0,0,0}, // 10 blank
  {0,0,0,0,0,0,0}, // 11 blank
  {1,1,1,1,0,0,0}, // 12 ° symbol
  {0,0,1,1,1,1,0}  // 13 C symbol
};

// Colors
uint32_t colorsHex[] = {
  0xFF0000, 0x00FF00, 0x0000FF,
  0xFFFF00, 0x00FFFF, 0xFF00FF,
  0xFFFFFF
};
const int NUM_PRESET_COLORS = sizeof(colorsHex)/sizeof(colorsHex[0]);
int colorIndex = 0;

// Modes
enum Mode { NORMAL, SET_TIME, SET_DATE, SHOW_TEMP };
Mode currentMode = NORMAL;
int settingIndex = 0;

// Temp values
int tempHour=0, tempMinute=0, tempDay=1, tempMonth=1, tempYear=2025;
bool use12h = false;

// Blink
unsigned long lastBlink = 0;
bool blinkState = true;

// Debounce & hold vars
const unsigned long DEBOUNCE_MS = 300;
const unsigned long HOLD_START_MS = 500;
const unsigned long REPEAT_MS = 150;

unsigned long lastModePress = 0, lastColorPress = 0, last1224Press = 0;
unsigned long pressStartUp = 0, pressStartDown = 0;
bool upHeld = false, downHeld = false;
unsigned long lastUpAction = 0, lastDownAction = 0;

// Colon LED indices
int colonLEDs[4];

// Animation vars
unsigned long lastHueUpdate = 0;
uint16_t baseHue = 0;
const unsigned long HUE_UPDATE_MS = 15; // Faster for smoother flow

// Temperature timing
unsigned long lastTempCheck = 0;
bool showingTemp = false;

void setup() {
  Serial.begin(9600);
  strip.begin();
  strip.setBrightness(BRIGHTNESS);
  strip.show();

  pinMode(BTN_MODE, INPUT_PULLUP);
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_COLOR, INPUT_PULLUP);
  pinMode(BTN_1224, INPUT_PULLUP);

  if (!rtc.begin()) {
    Serial.println("RTC not found!");
    while(1);
  }

  if (rtc.lostPower()) {
    rtc.adjust(DateTime(2025, 1, 23, 10, 30, 0));
  }

  use12h = (EEPROM.read(0) != 0);
  colorIndex = EEPROM.read(1);
  if (colorIndex < 0 || colorIndex > NUM_PRESET_COLORS) colorIndex = 0;

  int pos = 0;
  // Hour digits
  for (int i=0; i<2; i++) { digitStart[i]=pos; pos+=7*hourMinuteSegLEDs; }
  // Colon 1
  colonLEDs[0]=pos; colonLEDs[1]=pos+1; pos+=2;
  // Minute digits
  for (int i=2; i<4; i++) { digitStart[i]=pos; pos+=7*hourMinuteSegLEDs; }
  // Colon 2
  colonLEDs[2]=pos; colonLEDs[3]=pos+1; pos+=2;
  // Seconds
  for (int i=4; i<6; i++) { digitStart[i]=pos; pos+=7*secondSegLEDs; }
  // Date digits
  for (int i=8; i<14; i++) { digitStart[i]=pos; pos+=7*bottomSegLEDs; }

  DateTime now = rtc.now();
  tempHour = now.hour();
  tempMinute = now.minute();
  tempDay = now.day();
  tempMonth = now.month();
  tempYear = now.year();
}

void loop() {
  handleButtons();

  unsigned long t = millis();
  if (t - lastHueUpdate >= HUE_UPDATE_MS) {
    lastHueUpdate = t;
    baseHue++; // Smooth increment
  }

  if (millis() - lastBlink >= 500) {
    lastBlink = millis();
    blinkState = !blinkState;
  }

  DateTime now = rtc.now();

  if (currentMode == NORMAL && !showingTemp && millis() - lastTempCheck >= 20000) {
    showingTemp = true;
    lastTempCheck = millis();
    currentMode = SHOW_TEMP;
  }

  if (showingTemp && millis() - lastTempCheck >= 3000) {
    showingTemp = false;
    currentMode = NORMAL;
    lastTempCheck = millis();
  }

  if (currentMode == NORMAL) {
    tempHour = now.hour();
    tempMinute = now.minute();
    tempDay = now.day();
    tempMonth = now.month();
    tempYear = now.year();
    displayTimeDate(now);
  } else if (currentMode == SET_TIME || currentMode == SET_DATE) {
    displayTimeDate(now);
  } else if (currentMode == SHOW_TEMP) {
    displayTemperature(now);
  }
  strip.show();
}

void displayTimeDate(DateTime now){
  int values[12];
  int displayHour = tempHour;
  if (use12h){
    int h=tempHour%12;
    displayHour=(h==0)?12:h;
  }

  if (currentMode==SET_TIME && settingIndex==0 && !blinkState){ values[0]=-1; values[1]=-1; } 
  else { values[0]=(displayHour<10)?-1:displayHour/10; values[1]=displayHour%10; }

  if (currentMode==SET_TIME && settingIndex==1 && !blinkState){ values[2]=-1; values[3]=-1; } 
  else { values[2]=tempMinute/10; values[3]=tempMinute%10; }

  values[4]=now.second()/10;
  values[5]=now.second()%10;

  int yy=tempYear%100;
  if(currentMode==SET_DATE){
    values[6]=(settingIndex==0 && !blinkState)?-1:tempDay/10;
    values[7]=(settingIndex==0 && !blinkState)?-1:tempDay%10;
    values[8]=(settingIndex==1 && !blinkState)?-1:tempMonth/10;
    values[9]=(settingIndex==1 && !blinkState)?-1:tempMonth%10;
    values[10]=(settingIndex==2 && !blinkState)?-1:yy/10;
    values[11]=(settingIndex==2 && !blinkState)?-1:yy%10;
  } else {
    values[6]=tempDay/10; values[7]=tempDay%10;
    values[8]=tempMonth/10; values[9]=tempMonth%10;
    values[10]=yy/10; values[11]=yy%10;
  }

  strip.clear();
  for(int i=0;i<4;i++) drawDigit(i,values[i],hourMinuteSegLEDs);
  for(int i=4;i<6;i++) drawDigit(i,values[i],secondSegLEDs);
  for(int i=0;i<6;i++) drawDigit(8+i,values[6+i],bottomSegLEDs);

  bool rainbowMode = (colorIndex == NUM_PRESET_COLORS);
  if(now.second()%2==0 || currentMode!=NORMAL){
    for(int i=0;i<4;i++){
      if (rainbowMode) strip.setPixelColor(colonLEDs[i], wheel((baseHue + (colonLEDs[i] * 4)) & 255));
      else strip.setPixelColor(colonLEDs[i], hexToColor(colorsHex[colorIndex]));
    }
  }
}

void displayTemperature(DateTime now){
  strip.clear();
  float tempC = rtc.getTemperature();
  int tInt = (int)tempC;
  if (tInt < 10) { drawDigit(0, -1, hourMinuteSegLEDs); drawDigit(1, tInt, hourMinuteSegLEDs); } 
  else { drawDigit(0, tInt/10, hourMinuteSegLEDs); drawDigit(1, tInt%10, hourMinuteSegLEDs); }
  drawDigit(2, 12, hourMinuteSegLEDs);
  drawDigit(3, 13, hourMinuteSegLEDs);
  int yy = now.year() % 100;
  int dateValues[] = { now.day()/10, now.day()%10, now.month()/10, now.month()%10, yy/10, yy%10 };
  for(int i=0;i<6;i++) drawDigit(8+i, dateValues[i], bottomSegLEDs);
}

void drawDigit(int index,int num,int segLEDs){
  int base=digitStart[index];
  if(num==-1){
    for(int s=0;s<7;s++) for(int l=0;l<segLEDs;l++) strip.setPixelColor(base + s*segLEDs + l, 0);
    return;
  }
  if(num<0||num>13) num=0;
  bool rainbowMode = (colorIndex == NUM_PRESET_COLORS);
  for(int s=0;s<7;s++){
    for(int l=0;l<segLEDs;l++){
      int p = base + s*segLEDs + l;
      if(digitCode[num][s]){
        if (rainbowMode) strip.setPixelColor(p, wheel((baseHue + (p * 2)) & 255));
        else strip.setPixelColor(p, hexToColor(colorsHex[colorIndex]));
      } else strip.setPixelColor(p, 0);
    }
  }
}

void handleButtons(){
  unsigned long now=millis();
  if(!digitalRead(BTN_COLOR)&&now-lastColorPress>DEBOUNCE_MS){
    lastColorPress=now; colorIndex++; if (colorIndex > NUM_PRESET_COLORS) colorIndex = 0; EEPROM.update(1, colorIndex);
  }
  if(!digitalRead(BTN_1224)&&now-last1224Press>DEBOUNCE_MS){
    last1224Press=now; use12h=!use12h; EEPROM.update(0, use12h ? 1 : 0);
  }
  if(!digitalRead(BTN_MODE)&&now-lastModePress>DEBOUNCE_MS){
    lastModePress=now;
    if(currentMode==NORMAL) { currentMode=SET_TIME; settingIndex=0; }
    else if(currentMode==SET_TIME){ settingIndex++; if(settingIndex>1) { currentMode=SET_DATE; settingIndex=0; } }
    else if(currentMode==SET_DATE){ settingIndex++; if(settingIndex>2){ saveToRTC(); currentMode=NORMAL; settingIndex=0; } }
    else if(currentMode==SHOW_TEMP){ currentMode=NORMAL; showingTemp=false; }
  }
  if(!digitalRead(BTN_UP)){
    if(pressStartUp==0){ pressStartUp=now; if(now-lastUpAction>DEBOUNCE_MS){adjustValue(1); lastUpAction=now;} } 
    else { if(!upHeld && now-pressStartUp>=HOLD_START_MS){upHeld=true; lastUpAction=now;} if(upHeld && now-lastUpAction>=REPEAT_MS){adjustValue(1); lastUpAction=now;} }
  } else { pressStartUp=0; upHeld=false; }
  if(!digitalRead(BTN_DOWN)){
    if(pressStartDown==0){ pressStartDown=now; if(now-lastDownAction>DEBOUNCE_MS){adjustValue(-1); lastDownAction=now;} } 
    else { if(!downHeld && now-pressStartDown>=HOLD_START_MS){downHeld=true; lastDownAction=now;} if(downHeld && now-lastDownAction>=REPEAT_MS){adjustValue(-1); lastDownAction=now;} }
  } else { pressStartDown=0; downHeld=false; }
}

void adjustValue(int delta){
  if(currentMode==SET_TIME){
    if(settingIndex==0) tempHour=(tempHour+delta+24)%24;
    else tempMinute=(tempMinute+delta+60)%60;
  } else if(currentMode==SET_DATE){
    if(settingIndex==0){ int maxd=daysInMonth(tempMonth,tempYear); tempDay+=delta; if(tempDay<1) tempDay=maxd; if(tempDay>maxd) tempDay=1; } 
    else if(settingIndex==1){ tempMonth+=delta; if(tempMonth<1) tempMonth=12; if(tempMonth>12) tempMonth=1; } 
    else if(settingIndex==2){ tempYear+=delta; }
  }
}

int daysInMonth(int m,int y){
  if(m==4||m==6||m==9||m==11) return 30;
  if(m==2){bool leap=((y%4==0 && y%100!=0)||(y%400==0)); return leap?29:28;}
  return 31;
}

void saveToRTC(){ DateTime newdt(tempYear,tempMonth,tempDay,tempHour,tempMinute,0); rtc.adjust(newdt); }
uint32_t hexToColor(uint32_t hexVal){ return strip.Color((hexVal >> 16) & 0xFF, (hexVal >> 8) & 0xFF, hexVal & 0xFF); }
uint32_t wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if(WheelPos < 85) return strip.Color(255 - WheelPos * 3, 0, WheelPos * 3);
  if(WheelPos < 170) { WheelPos -= 85; return strip.Color(0, WheelPos * 3, 255 - WheelPos * 3); }
  WheelPos -= 170; return strip.Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}
`;

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-emerald-500/30">
      {/* Header */}
      <header className="border-b border-white/5 bg-black/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Clock className="w-6 h-6 text-black" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight">NeoPixel Simulator</h1>
              <p className="text-[10px] text-emerald-400 font-mono uppercase tracking-widest">v2.0 Enhanced Animation</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsPaused(!isPaused)}
              className="p-2 rounded-lg hover:bg-white/5 transition-colors"
            >
              {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
            </button>
            <button 
              onClick={() => {
                setTime(new Date());
                setCurrentMode(Mode.NORMAL);
                setSettingIndex(0);
              }}
              className="p-2 rounded-lg hover:bg-white/5 transition-colors"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Left Column: Simulator */}
        <div className="lg:col-span-8 space-y-8">
          {/* Clock Display Area */}
          <div className="relative min-h-[250px] sm:aspect-video bg-[#111] rounded-3xl border border-white/5 shadow-inner overflow-hidden flex flex-col items-center justify-center p-4 sm:p-8">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.05),transparent)] pointer-events-none" />
            
            {/* Main Time Display */}
            <div className="flex flex-wrap items-center justify-center mb-4 sm:mb-8 scale-[0.8] sm:scale-100">
              <Digit 
                value={Math.floor(getDisplayHour() / 10) === 0 && use12h ? -1 : Math.floor(getDisplayHour() / 10)} 
                ledsPerSegment={4} 
                color={currentColor} 
                isRainbow={isRainbow} 
                baseHue={baseHue} 
                startIndex={0}
              />
              <Digit 
                value={getDisplayHour() % 10} 
                ledsPerSegment={4} 
                color={currentColor} 
                isRainbow={isRainbow} 
                baseHue={baseHue} 
                startIndex={28}
              />
              
              {/* Colon 1 */}
              <div className="flex flex-col gap-4 sm:gap-8 mx-2 sm:mx-4">
                <div 
                  className="w-2 h-2 sm:w-3 sm:h-3 rounded-full shadow-lg transition-all duration-300"
                  style={{ 
                    backgroundColor: (time.getSeconds() % 2 === 0 || currentMode !== Mode.NORMAL) ? (isRainbow ? `hsl(${baseHue}, 100%, 50%)` : currentColor) : '#1a1a1a',
                    boxShadow: (time.getSeconds() % 2 === 0 || currentMode !== Mode.NORMAL) ? `0 0 12px ${isRainbow ? `hsl(${baseHue}, 100%, 50%)` : currentColor}` : 'none'
                  }}
                />
                <div 
                  className="w-2 h-2 sm:w-3 sm:h-3 rounded-full shadow-lg transition-all duration-300"
                  style={{ 
                    backgroundColor: (time.getSeconds() % 2 === 0 || currentMode !== Mode.NORMAL) ? (isRainbow ? `hsl(${baseHue + 10}, 100%, 50%)` : currentColor) : '#1a1a1a',
                    boxShadow: (time.getSeconds() % 2 === 0 || currentMode !== Mode.NORMAL) ? `0 0 12px ${isRainbow ? `hsl(${baseHue + 10}, 100%, 50%)` : currentColor}` : 'none'
                  }}
                />
              </div>

              <Digit 
                value={Math.floor(getDisplayMinute() / 10)} 
                ledsPerSegment={4} 
                color={currentColor} 
                isRainbow={isRainbow} 
                baseHue={baseHue} 
                startIndex={60}
              />
              <Digit 
                value={getDisplayMinute() % 10} 
                ledsPerSegment={4} 
                color={currentColor} 
                isRainbow={isRainbow} 
                baseHue={baseHue} 
                startIndex={88}
              />

              {/* Seconds (Smaller) */}
              <div className="flex items-end ml-4 mb-2">
                <Digit 
                  value={Math.floor(getDisplaySecond() / 10)} 
                  ledsPerSegment={3} 
                  color={currentColor} 
                  isRainbow={isRainbow} 
                  baseHue={baseHue} 
                  startIndex={118}
                />
                <Digit 
                  value={getDisplaySecond() % 10} 
                  ledsPerSegment={3} 
                  color={currentColor} 
                  isRainbow={isRainbow} 
                  baseHue={baseHue} 
                  startIndex={139}
                />
              </div>
            </div>

            {/* Date Display (Bottom) */}
            <div className="flex items-center gap-1 sm:gap-2 scale-[0.7] sm:scale-100">
              <Digit value={Math.floor(tempTime.day / 10)} ledsPerSegment={2} color={currentColor} isRainbow={isRainbow} baseHue={baseHue} startIndex={160} />
              <Digit value={tempTime.day % 10} ledsPerSegment={2} color={currentColor} isRainbow={isRainbow} baseHue={baseHue} startIndex={174} />
              <span className="text-gray-700 text-2xl font-bold mx-1">/</span>
              <Digit value={Math.floor(tempTime.month / 10)} ledsPerSegment={2} color={currentColor} isRainbow={isRainbow} baseHue={baseHue} startIndex={188} />
              <Digit value={tempTime.month % 10} ledsPerSegment={2} color={currentColor} isRainbow={isRainbow} baseHue={baseHue} startIndex={202} />
              <span className="text-gray-700 text-2xl font-bold mx-1">/</span>
              <Digit value={Math.floor((tempTime.year % 100) / 10)} ledsPerSegment={2} color={currentColor} isRainbow={isRainbow} baseHue={baseHue} startIndex={216} />
              <Digit value={(tempTime.year % 100) % 10} ledsPerSegment={2} color={currentColor} isRainbow={isRainbow} baseHue={baseHue} startIndex={230} />
            </div>

            {/* Mode Indicator */}
            <div className="absolute top-6 right-6 flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10">
              <div className={`w-2 h-2 rounded-full ${currentMode === Mode.NORMAL ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`} />
              <span className="text-[10px] font-mono uppercase tracking-wider text-gray-400">
                {Mode[currentMode].replace('_', ' ')}
              </span>
            </div>
          </div>

          {/* Controls Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            <ControlButton icon={<Settings />} label="Mode" onClick={handleMode} color="bg-blue-500" />
            <ControlButton icon={<Play className="rotate-[-90deg]" />} label="Up" onClick={() => handleAdjust(1)} color="bg-emerald-500" />
            <ControlButton icon={<Play className="rotate-[90deg]" />} label="Down" onClick={() => handleAdjust(-1)} color="bg-emerald-500" />
            <ControlButton icon={<Palette />} label="Color" onClick={() => setColorIndex(prev => (prev + 1) % (PRESET_COLORS.length + 1))} color="bg-purple-500" />
            <ControlButton icon={<Clock />} label="12/24H" onClick={() => setUse12h(!use12h)} color="bg-amber-500" />
          </div>

          {/* Info Section */}
          <div className="bg-white/5 rounded-2xl p-6 border border-white/10">
            <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              Simulator Features
            </h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-gray-400">
              <li className="flex items-center gap-2"><div className="w-1 h-1 rounded-full bg-emerald-500" /> Real-time RTC Simulation</li>
              <li className="flex items-center gap-2"><div className="w-1 h-1 rounded-full bg-emerald-500" /> 7-Segment LED Logic</li>
              <li className="flex items-center gap-2"><div className="w-1 h-1 rounded-full bg-emerald-500" /> Smooth Rainbow Flow Animation</li>
              <li className="flex items-center gap-2"><div className="w-1 h-1 rounded-full bg-emerald-500" /> 12/24 Hour Toggle Support</li>
              <li className="flex items-center gap-2"><div className="w-1 h-1 rounded-full bg-emerald-500" /> Temperature Auto-Display Logic</li>
              <li className="flex items-center gap-2"><div className="w-1 h-1 rounded-full bg-emerald-500" /> EEPROM State Persistence (Simulated)</li>
            </ul>
          </div>
        </div>

        {/* Right Column: Code & Settings */}
        <div className="lg:col-span-4 space-y-8">
          <div className="flex flex-col gap-4">
            <h2 className="text-sm font-bold uppercase tracking-widest text-gray-500">Arduino Integration</h2>
            <ArduinoCode code={enhancedArduinoCode} />
          </div>

          <div className="bg-white/5 rounded-2xl p-6 border border-white/10 space-y-6">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <Settings className="w-4 h-4 text-emerald-400" />
              Settings
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-400">Time Format</span>
                <button 
                  onClick={() => setUse12h(!use12h)}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${use12h ? 'bg-emerald-500 text-black' : 'bg-white/10 text-white'}`}
                >
                  {use12h ? '12 HOUR' : '24 HOUR'}
                </button>
              </div>

              <div className="space-y-2">
                <span className="text-xs text-gray-400 block">Active Color</span>
                <div className="flex flex-wrap gap-2">
                  {PRESET_COLORS.map((c, i) => (
                    <button
                      key={i}
                      onClick={() => setColorIndex(i)}
                      className={`w-6 h-6 rounded-full border-2 transition-all ${colorIndex === i ? 'border-white scale-110' : 'border-transparent opacity-50'}`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                  <button
                    onClick={() => setColorIndex(PRESET_COLORS.length)}
                    className={`w-6 h-6 rounded-full border-2 transition-all bg-gradient-to-tr from-red-500 via-green-500 to-blue-500 ${colorIndex === PRESET_COLORS.length ? 'border-white scale-110' : 'border-transparent opacity-50'}`}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-white/5 py-12 bg-black/50">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-xs text-gray-500">
            Designed for high-performance LED clock systems. 
            <br />
            <span className="text-emerald-500/50 mt-2 block">© 2026 NeoPixel Simulator Pro</span>
          </p>
        </div>
      </footer>
    </div>
  );
}

function ControlButton({ icon, label, onClick, color }: { icon: React.ReactNode, label: string, onClick: () => void, color: string }) {
  return (
    <button 
      onClick={onClick}
      className="group relative flex flex-col items-center justify-center p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all active:scale-95"
    >
      <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center mb-3 shadow-lg group-hover:scale-110 transition-transform`}>
        {React.cloneElement(icon as React.ReactElement, { className: 'w-6 h-6 text-black' })}
      </div>
      <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400 group-hover:text-white transition-colors">{label}</span>
    </button>
  );
}
