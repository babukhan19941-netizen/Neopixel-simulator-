export interface Pixel {
  id: number;
  x: number;
  y: number;
  color: string;
}

export interface DigitConfig {
  startIndex: number;
  ledsPerSegment: number;
  type: 'large' | 'medium' | 'small';
}

export const SEGMENT_MAP = [
  [0, 1, 1, 1, 1, 1, 1], // 0
  [0, 1, 0, 0, 0, 0, 1], // 1
  [1, 1, 1, 0, 1, 1, 0], // 2
  [1, 1, 1, 0, 0, 1, 1], // 3
  [1, 1, 0, 1, 0, 0, 1], // 4
  [1, 0, 1, 1, 0, 1, 1], // 5
  [1, 0, 1, 1, 1, 1, 1], // 6
  [0, 1, 1, 0, 0, 0, 1], // 7
  [1, 1, 1, 1, 1, 1, 1], // 8
  [1, 1, 1, 1, 0, 1, 1], // 9
  [0, 0, 0, 0, 0, 0, 0], // 10 blank
  [0, 0, 0, 0, 0, 0, 0], // 11 blank
  [1, 1, 1, 1, 0, 0, 0], // 12 ° symbol
  [0, 0, 1, 1, 1, 1, 0]  // 13 C symbol
];

// Segment order in code: G, B, A, F, E, D, C
// Standard 7-segment layout:
//      A
//    F   B
//      G
//    E   C
//      D
export const SEGMENT_LAYOUT = [
  'G', 'B', 'A', 'F', 'E', 'D', 'C'
];

export const PRESET_COLORS = [
  '#FF0000', '#00FF00', '#0000FF',
  '#FFFF00', '#00FFFF', '#FF00FF',
  '#FFFFFF'
];
