import React from 'react';
import { SEGMENT_MAP } from '../constants';

interface DigitProps {
  value: number;
  ledsPerSegment: number;
  color: string;
  isRainbow: boolean;
  baseHue: number;
  startIndex: number;
}

const Digit: React.FC<DigitProps> = ({ value, ledsPerSegment, color, isRainbow, baseHue, startIndex }) => {
  const segments = value === -1 ? [0, 0, 0, 0, 0, 0, 0] : SEGMENT_MAP[value] || [0, 0, 0, 0, 0, 0, 0];

  // Helper to get rainbow color
  const getRainbowColor = (pixelIndex: number) => {
    const hue = (baseHue + (pixelIndex * 2)) % 360;
    return `hsl(${hue}, 100%, 50%)`;
  };

  const renderSegment = (segIdx: number, type: string) => {
    const isActive = segments[segIdx] === 1;
    const leds = [];
    for (let i = 0; i < ledsPerSegment; i++) {
      const pixelId = startIndex + segIdx * ledsPerSegment + i;
      const ledColor = isActive 
        ? (isRainbow ? getRainbowColor(pixelId) : color)
        : '#1a1a1a';
      
      leds.push(
        <div 
          key={i} 
          className="w-1 h-1 sm:w-2 sm:h-2 rounded-full shadow-lg transition-colors duration-200"
          style={{ 
            backgroundColor: ledColor,
            boxShadow: isActive ? `0 0 8px ${ledColor}` : 'none'
          }}
        />
      );
    }

    // Position segments based on standard 7-segment layout
    // G, B, A, F, E, D, C
    const positions: Record<number, string> = {
      2: "top-0 left-1/2 -translate-x-1/2 flex-row", // A
      1: "top-1 right-0 flex-col",                  // B
      6: "bottom-1 right-0 flex-col",               // C
      5: "bottom-0 left-1/2 -translate-x-1/2 flex-row", // D
      4: "bottom-1 left-0 flex-col",                // E
      3: "top-1 left-0 flex-col",                   // F
      0: "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex-row", // G
    };

    return (
      <div key={segIdx} className={`absolute flex gap-0.5 ${positions[segIdx]}`}>
        {leds}
      </div>
    );
  };

  return (
    <div className="relative w-10 h-16 sm:w-16 sm:h-28 mx-1 sm:mx-2">
      {[0, 1, 2, 3, 4, 5, 6].map(i => renderSegment(i, ''))}
    </div>
  );
};

export default Digit;
