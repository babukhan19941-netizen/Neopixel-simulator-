import React from 'react';

interface CodeProps {
  code: string;
}

const ArduinoCode: React.FC<CodeProps> = ({ code }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-[#1e1e1e] rounded-xl overflow-hidden border border-white/10 shadow-2xl">
      <div className="flex items-center justify-between px-4 py-2 bg-[#252526] border-bottom border-white/5">
        <span className="text-xs font-mono text-gray-400">Enhanced_Clock.ino</span>
        <button 
          onClick={handleCopy}
          className="text-xs font-medium px-3 py-1 rounded bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition-colors"
        >
          {copied ? 'Copied!' : 'Copy Code'}
        </button>
      </div>
      <pre className="p-4 overflow-auto max-h-[500px] text-sm font-mono text-gray-300 leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  );
};

export default ArduinoCode;
